package com.example.animations_d

import android.app.NotificationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.core.app.NotificationCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // initialization of UI elements
        var imageView:ImageView = findViewById(R.id.imageView)

        var animation1:Button = findViewById(R.id.button)
        var animation2:Button = findViewById(R.id.button3)
        var sendNotif:Button = findViewById(R.id.button2)

        var notifTitle : EditText = findViewById(R.id.NTitle)
        var notifContent : EditText = findViewById(R.id.NSubTitle)


        animation1.setOnClickListener({
            // animation 1 will get loaded on imageview on clicking this button
       var animObject :Animation = AnimationUtils.loadAnimation(this,
       R.anim.animation03)

            imageView.startAnimation(animObject)

        })
        animation2.setOnClickListener({
            // animation 02 will get loaded on imageview on clicking this button
            var animation: Animation = AnimationUtils.loadAnimation(this, R.anim.animation02)
            imageView.startAnimation(animation)
        })

sendNotif.setOnClickListener({

    var notifobject = NotificationCompat.Builder(this)
    notifobject.setSmallIcon(R.drawable.ic_launcher_background)
    notifobject.setContentTitle(notifTitle.text.toString())
    notifobject.setContentText(notifContent.text.toString())

    var notimanager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
    notimanager.notify(101, notifobject.build())


})

    }
}