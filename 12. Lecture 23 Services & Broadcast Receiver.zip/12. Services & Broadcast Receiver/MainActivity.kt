package com.example.services_c

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var startButton:Button = findViewById(R.id.start)
        var stopButton:Button = findViewById(R.id.stop)


        startButton.setOnClickListener({
//            start your service here

            var serviceIntent : Intent = Intent(this, MyBackgroundService::class.java)
            startService(serviceIntent)


        })

        stopButton.setOnClickListener({
//            stop your service here
            stopService(Intent(this, MyBackgroundService::class.java))


        })




    }
}