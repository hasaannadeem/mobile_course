package com.example.services_c

import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder
import android.widget.Toast

class MyBackgroundService : Service() {

    override fun onBind(intent: Intent): IBinder {
        TODO("Return the communication channel to the service.")
    }


    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Toast.makeText(this, "Service is started", Toast.LENGTH_SHORT).show()


        var mysignal:MySignalReceiver = MySignalReceiver()
        var filter = IntentFilter()
        filter.addAction(Intent.ACTION_BATTERY_CHANGED)
        filter.addAction(Intent.ACTION_HEADSET_PLUG)
        filter.addAction("android.provider.Telephony.SMS_RECEIVED")
        filter.addAction(Intent.ACTION_TIME_TICK)


        registerReceiver(mysignal, filter)


        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(MySignalReceiver())



        Toast.makeText(this, "SErvice is stopped", Toast.LENGTH_SHORT).show()
    }
    
}