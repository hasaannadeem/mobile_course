package com.example.services_c

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

class MySignalReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        // This method is called when the BroadcastReceiver is receiving an Intent broadcast.


        var action = intent.action
        if(action == Intent.ACTION_HEADSET_PLUG)
            Toast.makeText(context, "Handsfree detected", Toast.LENGTH_SHORT).show()
        if(action  == Intent.ACTION_TIME_TICK)
            Toast.makeText(context, "Time is changed", Toast.LENGTH_SHORT).show()
        if(action == Intent.ACTION_BATTERY_CHANGED)
            Toast.makeText(context, "Battary status is changed", Toast.LENGTH_SHORT).show()
        if(action == "android.provider.Telephony.SMS_RECEIVED")
            Toast.makeText(context, "A SMS received", Toast.LENGTH_SHORT).show()
    }
}