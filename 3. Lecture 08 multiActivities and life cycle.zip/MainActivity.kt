package com.example.multiactivities_d

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onDestroy() {
        super.onDestroy()
        Toast.makeText(MainActivity@this, "I am in Destroy phase", Toast.LENGTH_SHORT).show()

    }
    override fun onStop() {
        super.onStop()
        Toast.makeText(MainActivity@this, "I am in onStop phase", Toast.LENGTH_SHORT).show()

    }
    override fun onPause() {
        super.onPause()
        Toast.makeText(MainActivity@this, "I am in onPause phase", Toast.LENGTH_SHORT).show()

    }
    override fun onRestart() {
        super.onRestart()
        Toast.makeText(MainActivity@this, "I am in onRestart phase", Toast.LENGTH_SHORT).show()

    }
    override fun onResume() {
        super.onResume()
        Toast.makeText(MainActivity@this, "I am in onResume phase", Toast.LENGTH_SHORT).show()

    }
    override fun onStart() {
        super.onStart()
        Toast.makeText(MainActivity@this, "I am in onstart phase", Toast.LENGTH_SHORT).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var nextActivity: Button = findViewById(R.id.button)
        var s3: Button = findViewById(R.id.s3)
        val etEmail:EditText = findViewById(R.id.etEmail)


        s3.setOnClickListener({
            startActivity(Intent(this, ThirdActivit::class.java))
        })

        nextActivity.setOnClickListener({
            //  button click block executes here

            val emailAddress = etEmail.text.toString()
            var shifter : Intent = Intent(this, SecondActivity::class.java)
            shifter.putExtra("ConfidentialInfo", emailAddress)
            startActivity(shifter)
            finish()


        })




    }// oncreate method
}// end of class