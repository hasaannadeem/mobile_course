package com.example.multiactivities_d

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class SecondActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        
        
        val receivedData: String? = intent.getStringExtra("ConfidentialInfo")
        Toast.makeText(this, "I have received data: $receivedData", Toast.LENGTH_SHORT).show()
        val tv:TextView = findViewById(R.id.textView)
        tv.setText("$receivedData")

        
        val move : Button = findViewById(R.id.button2)
        move.setOnClickListener({

            //        val move = Intent(SecondActivity@this, MainActivity::class.java)
//        startActivity(move)
            startActivity(Intent(this, MainActivity::class.java))
            finish()

        })






    }
}