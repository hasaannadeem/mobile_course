package com.example.gps_location_c

import android.app.ProgressDialog
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val tv:TextView = findViewById(R.id.textView)
        val get:Button = findViewById(R.id.button)
        
        ActivityCompat.requestPermissions(MainActivity@this,
        arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION,
        android.Manifest.permission.ACCESS_COARSE_LOCATION), 
        569)
        

        val prog:ProgressDialog = ProgressDialog(MainActivity@this)
        prog.setMessage("Getting Your location...")
        prog.setTitle("Please wait")

        get.setOnClickListener({
            // get your location here when this button is pressed


            prog.show()
            val locManager : LocationManager = getSystemService(LOCATION_SERVICE) as LocationManager

            val locObject:MyLocationClass = MyLocationClass(tv, prog)
            locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0f, locObject)
            
//            locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0f, object:LocationListener{
//
//                override fun onLocationChanged(p: Location) {
//
//                    val lat:Double = p.latitude
//                    val lon:Double = p.longitude
//                    
//                    tv.setText("Your location is: \nLatitude: $lat \n Longitude: $lon")
//
//
//                }

            })


   




    }// oncreate ends here

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
        {
            
        }
        else
            Toast.makeText(MainActivity@ this, "Permission denied by user", Toast.LENGTH_SHORT).show()
        
    }


}// class ends here