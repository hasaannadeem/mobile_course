package com.example.geocoder_gps_c

import android.location.Address
import android.location.Geocoder
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import java.util.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



        ActivityCompat.requestPermissions(MainActivity@this,
        arrayOf(android.Manifest.permission.INTERNET),
        187)

        val etLat:EditText =  findViewById(R.id.editTextNumberDecimal)
        val etlon:EditText =  findViewById(R.id.editTextNumberDecimal2)
        val display:TextView =  findViewById(R.id.textView)
        val goecode:Button =  findViewById(R.id.button)

        goecode.setOnClickListener({

            // read values and then convert
            val lat: Double = etLat.text.toString().toDouble()
            val lon: Double = etlon.text.toString().toDouble()

            val locationConverter: Geocoder = Geocoder(MainActivity@ this, Locale.getDefault())
            val addr: List<Address> = locationConverter.getFromLocation(lat, lon, 1)
            val finalAddress = addr[0]

            val country: String = finalAddress.countryName
            val city = finalAddress.adminArea
            val subAdminArea = finalAddress.subAdminArea
            val locality = finalAddress.locality
            val sub_locality = finalAddress.subLocality
            val name = finalAddress.featureName
            val addressLine = finalAddress.getAddressLine(0)

            val completeAddress =
                "Your address is: \nCountry: $country \n City : $city \nSubAdmin Area: $subAdminArea \n Locality: $locality \nSub Locality: $sub_locality \nName: $name \n $addressLine"

            display.setText(completeAddress)

            val alertMessage: AlertDialog.Builder = AlertDialog.Builder(MainActivity@ this)
            alertMessage.setTitle("Result of Geocoder")
            alertMessage.setMessage(completeAddress)
            alertMessage.setPositiveButton("OK", { a, b ->
                // code to be executed on pressing ok button of alert message
            })
            alertMessage.setNegativeButton("Cancel", { id, dialog ->
            })

            alertMessage.setNeutralButton("Done", { id, d ->
                Toast.makeText(MainActivity@ this, "You pressed done button", Toast.LENGTH_SHORT).show()
            })

            alertMessage.create()
            alertMessage.show()


        })// end of button geocode click




    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }

}