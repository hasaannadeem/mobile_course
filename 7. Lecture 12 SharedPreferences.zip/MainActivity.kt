package com.example.sharedpreferences_c

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {

    lateinit var sp:SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        var counter = 0
        val etname:EditText = findViewById(R.id.editTextTextPersonName)
        val etemail:EditText = findViewById(R.id.editTextTextEmailAddress)
        val etpass:EditText = findViewById(R.id.editTextTextPassword)
        val etage:EditText = findViewById(R.id.editTextNumber)

        val save:Button = findViewById(R.id.button)
        val load:Button = findViewById(R.id.button2)

        val display :TextView = findViewById(R.id.textView)
        sp= getSharedPreferences("MyTinyDatabase", Context.MODE_PRIVATE)

        save.setOnClickListener({
            // save data here

            val name=etname.text.toString()
            val email=etemail.text.toString()
            val pass=etpass.text.toString()
            val age=etage.text.toString().toInt()


            val dataEditor : SharedPreferences.Editor  = sp.edit()


            counter = sp.getInt("counter", 0)

            dataEditor.putString("par1"+counter, name)
            dataEditor.putString("email"+counter, email)
            dataEditor.putString("password"+counter, pass)
            dataEditor.putInt("par4"+counter, age)


            counter++
            dataEditor.putInt("counter", counter)

            dataEditor.apply()
            dataEditor.commit()

            etname.setText(null)
            etemail.setText(null)
            etname.setText(null)
            etname.setText(null)


        })

        load.setOnClickListener({
            // display your data here

            var start =0
            var complete=""
            while(start<counter)
            {
                val par1 = sp.getString("par1"+start, "undefined name")
                val par2 = sp.getString("email"+start, "undefined email")
                val par3 = sp.getString("password"+start, "no password")
                val par4 = sp.getInt("par4"+start, 0)

                complete+= "Name: $par1 \n Email: $par2 \n Password: $par3 \n Age: $par4\n\n"
                start++
            }
            display.setText(complete)


        })


    }// oncreat method ends here
}