package com.example.firebase_c

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


        val etEmail : EditText = findViewById(R.id.editTextTextEmailAddress)
        val etPass : EditText = findViewById(R.id.editTextTextPassword)
        val btnCreate : Button = findViewById(R.id.button)


        btnCreate.setOnClickListener({

            // create a user account here
            val email = etEmail.text.toString()
            val pass = etPass.text.toString()

            val dbAuth: FirebaseAuth = Firebase.auth

            dbAuth.createUserWithEmailAndPassword(email, pass)
                    .addOnCompleteListener(MainActivity@ this)
                    {

                        task ->
                        if (task.isSuccessful)
                            Toast.makeText(MainActivity@ this, "Your account is created", Toast.LENGTH_SHORT).show()
                        else
                            Toast.makeText(MainActivity@ this, "Not created: "+task.exception.toString(), Toast.LENGTH_SHORT).show()


                        etEmail.setText(null)
                        etPass.setText(null)

                    }


        })// this is end of button click





    }// end of on create method
}// end of class