package com.example.sqlitedatabase_c

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var regno : EditText = findViewById(R.id.stdreg)
        var name : EditText = findViewById(R.id.stdname)
        var cgpa : EditText = findViewById(R.id.stdcgpa)
        var email : EditText = findViewById(R.id.stdEmail)
        var mingpa : EditText = findViewById(R.id.mingpa)
        var maxGPA : EditText = findViewById(R.id.maxgpa)
        var patternET : EditText = findViewById(R.id.pattern)

        var save : Button = findViewById(R.id.button)
        var readAll : Button = findViewById(R.id.button2)
        var filterButton : Button = findViewById(R.id.filterButton)
        var patternbutton : Button = findViewById(R.id.patternbutton)

        patternbutton.setOnClickListener({
            MyDatabaseClass(this).getPatternData(patternET.text.toString())


        })


        filterButton.setOnClickListener({
            // it will get filtered students
//            var obj = MyDatabaseClass(this)
//            obj.getFilteredStudents(mingpa.text.toString().toFloat(),
//            maxGPA.text.toString().toFloat())

            MyDatabaseClass(this).getFilteredStudents(mingpa.text.toString().toFloat(),
            maxGPA.text.toString().toFloat())

        })



        save.setOnClickListener({
            // data will be saved here
            // reading data from interface
            var strReg = regno.text.toString()
            var strname = name.text.toString()
            var stremail = email.text.toString()
            var floatcgpa = cgpa.text.toString().toFloat()

            var myDB:MyDatabaseClass = MyDatabaseClass(this)
            myDB.insertRecord(strReg, strname, stremail, floatcgpa)





        })


        readAll.setOnClickListener({
            // data will be fetched here
            var db = MyDatabaseClass(this)
            db.ReadAllRecords()

        })





    }
}

