package com.example.sqlitedatabase_c

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.CursorAdapter
import android.widget.Toast

class MyDatabaseClass(var view:Context) : SQLiteOpenHelper(view, "MyDatabase.db", null, 1)
{
val tableName = "Student"
    override fun onCreate(db: SQLiteDatabase?) {
        var tableQuery:String = "CREATE TABLE $tableName(ID Integer primary key autoincrement , REGNO VARCHAR(20), NAME CHAR(32), EMAIL VARCHAR(100), CGPA FLOAT )"
        db?.execSQL(tableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE if exists $tableName")
        onCreate(db)
    }



    fun insertRecord(parReg:String, parName:String, parEmail:String, parCGPA:Float)
    {
        var db = writableDatabase
//        var insertQuery = "INSERT INTO Student VALUES($parReg, $parName, $parEmail, $parCGPA)"
//        db.exe(insertQuery)
        var contValue : ContentValues = ContentValues()

        contValue.put("REGNO", parReg)
        contValue.put("NAME", parName)
        contValue.put("EMAIL", parEmail)
        contValue.put("CGPA", parCGPA)
        var insertResult = db.insert(tableName, "ID", contValue)

        if(insertResult>0)
            Toast.makeText(view, "Record is inserted: $insertResult", Toast.LENGTH_SHORT).show()
        else
            Toast.makeText(view, "Record not saved... $insertResult", Toast.LENGTH_SHORT).show()

    }



    fun ReadAllRecords()
    {

        var db = readableDatabase
        var readQuery = "Select * from $tableName"
        var allData : Cursor = db.rawQuery(readQuery, null)
        var size = allData.count
        
        var x=0
        allData.moveToFirst()
        var completeData=""
        while(x<size)
        {
            var col1 = allData.getInt(allData.getColumnIndex("ID"))
            var col2 = allData.getString(allData.getColumnIndex("REGNO"))
            var col3 = allData.getString(allData.getColumnIndex("NAME"))
            var col4 = allData.getString(allData.getColumnIndex("EMAIL"))
            var col5 = allData.getFloat(allData.getColumnIndex("CGPA"))

            completeData+= "Record No. ${x+1}\n$col1 \n $col2 \n" +
                    " $col3 \n" +
                    " $col4 \n" +
                    " $col5\n______________________\n\n"
            Toast.makeText(view, "$col2 \n $col3 \n $col4 \n $col5", Toast.LENGTH_SHORT).show()
            
            allData.moveToNext()
            x++
        }// end of while loop
        var info = AlertDialog.Builder(view)
        info.setTitle("All Data: ")
        info.setMessage(completeData)
        info.setPositiveButton("Cancel", {a, b ->})
        info.create()
        info.show()




    }// get all students


    fun getFilteredStudents(minGPA:Float, maxGPA:Float)
    {

        var db = readableDatabase
        var readQuery = "Select * from $tableName where CGPA>=$minGPA and CGPA <=$maxGPA"
        var allData : Cursor = db.rawQuery(readQuery, null)
        var size = allData.count

        var x=0
        allData.moveToFirst()
        var completeData=""
        while(x<size)
        {
//            var col1 = allData.getInt(allData.getColumnIndex("ID"))
            var col2 = allData.getString(allData.getColumnIndex("REGNO"))
            var col3 = allData.getString(allData.getColumnIndex("NAME"))
            var col4 = allData.getString(allData.getColumnIndex("EMAIL"))
            var col5 = allData.getFloat(allData.getColumnIndex("CGPA"))

            completeData+= "Record No. ${x+1}\n$col2 \n" +
                    " $col3 \n" +
                    " $col4 \n" +
                    " $col5\n______________________\n\n"
            Toast.makeText(view, "$col2 \n $col3 \n $col4 \n $col5", Toast.LENGTH_SHORT).show()

            allData.moveToNext()
            x++
        }// end of while loop
        var info = AlertDialog.Builder(view)
        info.setTitle("Filtered Students!")
        info.setMessage(completeData)
        info.setPositiveButton("Cancel", {a, b ->})
        info.create()
        info.show()





    }// get filtered students

    fun getPatternData(pattern:String)
    {

        var db = readableDatabase
        var readQuery = "Select * from $tableName where NAME like '$pattern'"
        var allData : Cursor = db.rawQuery(readQuery, null)
        var size = allData.count

        var x=0
        allData.moveToFirst()
        var completeData=""
        while(x<size)
        {
//            var col1 = allData.getInt(allData.getColumnIndex("ID"))
            var col2 = allData.getString(allData.getColumnIndex("REGNO"))
            var col3 = allData.getString(allData.getColumnIndex("NAME"))
            var col4 = allData.getString(allData.getColumnIndex("EMAIL"))
            var col5 = allData.getFloat(allData.getColumnIndex("CGPA"))

            completeData+= "Record No. ${x+1}\n$col2 \n" +
                    " $col3 \n" +
                    " $col4 \n" +
                    " $col5\n______________________\n\n"
            Toast.makeText(view, "$col2 \n $col3 \n $col4 \n $col5", Toast.LENGTH_SHORT).show()

            allData.moveToNext()
            x++
        }// end of while loop
        var info = AlertDialog.Builder(view)
        info.setTitle("Patterned Students!")
        info.setMessage(completeData)
        if(completeData.length<1)
            info.setMessage("No record found")
        info.setPositiveButton("Cancel", {a, b ->})
        info.create()
        info.show()





    }

}